import React, { createContext, useContext, useState } from 'react';

export interface Item {
  id: string;
  name: string;
  quantity: number;
  price: number;
  categoryId: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface Coach {
  id: string;
  name: string;
  items: { itemId: string; quantity: number; date?: string }[];
}

export interface Sale {
  id: string;
  itemId: string;
  itemName: string;
  quantity: number;
  price: number;
  total: number;
  date: string;
  type: 'direct' | 'coach';
}

interface AppContextType {
  isLoggedIn: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  categories: Category[];
  items: Item[];
  coaches: Coach[];
  sales: Sale[];
  addCategory: (name: string) => void;
  addItem: (name: string, quantity: number, price: number, categoryId: string) => void;
  updateItem: (id: string, updates: Partial<Item>) => void;
  addCoach: (name: string) => void;
  addSale: (sale: Omit<Sale, 'id'>) => void;
  assignItemToCoach: (coachId: string, itemId: string, quantity: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [coaches, setCoaches] = useState<Coach[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);

  const login = (email: string, password: string) => {
    if (email === 'pavank200414@gmail.com' && password === 'adminoflevelz') {
      setIsLoggedIn(true);
      return true;
    }
    return false;
  };

  const logout = () => setIsLoggedIn(false);

  const addCategory = (name: string) => {
    const newCategory: Category = {
      id: Date.now().toString(),
      name
    };
    setCategories(prev => [...prev, newCategory]);
  };

  const addItem = (name: string, quantity: number, price: number, categoryId: string) => {
    const newItem: Item = {
      id: Date.now().toString(),
      name,
      quantity,
      price,
      categoryId
    };
    setItems(prev => [...prev, newItem]);
  };

  const updateItem = (id: string, updates: Partial<Item>) => {
    setItems(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const addCoach = (name: string) => {
    const newCoach: Coach = {
      id: Date.now().toString(),
      name,
      items: []
    };
    setCoaches(prev => [...prev, newCoach]);
  };

  const addSale = (sale: Omit<Sale, 'id'>) => {
    const newSale: Sale = {
      ...sale,
      id: Date.now().toString()
    };
    setSales(prev => [...prev, newSale]);
  };

  const assignItemToCoach = (coachId: string, itemId: string, quantity: number) => {
    setCoaches(prev => prev.map(coach => 
      coach.id === coachId 
        ? { ...coach, items: [...coach.items, { itemId, quantity, date: new Date().toISOString() }] }
        : coach
    ));
  };

  return (
    <AppContext.Provider value={{
      isLoggedIn,
      login,
      logout,
      categories,
      items,
      coaches,
      sales,
      addCategory,
      addItem,
      updateItem,
      addCoach,
      addSale,
      assignItemToCoach
    }}>
      {children}
    </AppContext.Provider>
  );
};