import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import CoachSelector from './CoachSelector';
import CoachDetails from './CoachDetails';
import AddCoachForm from './AddCoachForm';
import { Coach } from '@/contexts/AppContext';

type ViewState = 'coaches' | 'coachDetails' | 'addCoach';

const AcademyTab: React.FC = () => {
  const { coaches, items, addCoach, assignItemToCoach } = useAppContext();
  const [currentView, setCurrentView] = useState<ViewState>('coaches');
  const [selectedCoach, setSelectedCoach] = useState<Coach | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();

  const handleCoachSelect = (coach: Coach) => {
    setSelectedCoach(coach);
    setCurrentView('coachDetails');
  };

  const handleAddCoach = (name: string) => {
    addCoach(name);
    setCurrentView('coaches');
    toast({
      title: 'Coach Added',
      description: `Coach "${name}" has been added.`,
    });
  };

  const handleAssignItem = () => {
    // Simple assignment - just assign first available item for demo
    if (selectedCoach && items.length > 0) {
      const firstItem = items[0];
      assignItemToCoach(selectedCoach.id, firstItem.id, 1);
      toast({
        title: 'Item Assigned',
        description: `${firstItem.name} assigned to ${selectedCoach.name}`,
      });
    }
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'coaches':
        return (
          <CoachSelector
            coaches={coaches}
            onCoachSelect={handleCoachSelect}
            onAddCoach={() => setCurrentView('addCoach')}
          />
        );
      case 'coachDetails':
        return selectedCoach ? (
          <CoachDetails
            coach={selectedCoach}
            items={items}
            onBack={() => setCurrentView('coaches')}
            onAssignItem={handleAssignItem}
            onDateFilter={setSelectedDate}
            selectedDate={selectedDate}
          />
        ) : null;
      case 'addCoach':
        return (
          <AddCoachForm
            onBack={() => setCurrentView('coaches')}
            onAdd={handleAddCoach}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {renderCurrentView()}
    </div>
  );
};

export default AcademyTab;