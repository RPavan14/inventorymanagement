import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Plus, UserPlus } from 'lucide-react';

interface AddCoachFormProps {
  onBack: () => void;
  onAdd: (name: string) => void;
}

const AddCoachForm: React.FC<AddCoachFormProps> = ({
  onBack,
  onAdd
}) => {
  const [coachName, setCoachName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (coachName.trim()) {
      onAdd(coachName.trim());
      setCoachName('');
    }
  };

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader className="bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center space-x-2">
          <UserPlus className="w-5 h-5" />
          <span>Add New Coach</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Button
            type="button"
            onClick={onBack}
            variant="outline"
            className="w-full"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Coaches
          </Button>

          <div>
            <Label htmlFor="coachName">Coach Name</Label>
            <Input
              id="coachName"
              value={coachName}
              onChange={(e) => setCoachName(e.target.value)}
              placeholder="Enter coach name"
              className="mt-1"
              required
            />
          </div>

          <Button
            type="submit"
            disabled={!coachName.trim()}
            className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Coach
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default AddCoachForm;